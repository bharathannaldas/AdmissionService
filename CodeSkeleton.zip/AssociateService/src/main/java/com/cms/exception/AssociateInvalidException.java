package com.cms.exception;

public class AssociateInvalidException extends Exception {

	
	public AssociateInvalidException(String message)
	{
		super(message);
	}
	public AssociateInvalidException() {
	}
}
