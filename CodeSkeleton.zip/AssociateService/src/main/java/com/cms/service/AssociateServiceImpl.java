package com.cms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cms.exception.AssociateInvalidException;
import com.cms.model.Associate;

@Service
public class AssociateServiceImpl implements IAssociateService{
	
	
	private ArrayList<Associate> associateList=new ArrayList<Associate>();
	
	public ArrayList<Associate> getAssociateList() {
		return associateList;
	}

	public void setAssociateList(ArrayList<Associate> associateList) {
		this.associateList = associateList;
	}

	public AssociateServiceImpl()
	{
//		Associate accObj1=new Associate("A601","sathya","coimbatore","sathya@gmail.com");
//		Associate accObj2=new Associate("A602","priya","chennai","priya@gmail.com");
//		Associate accObj3=new Associate("A603","ram","salem","ram@gmail.com");
//		Associate accObj4=new Associate("A604","somu","coimbatore","somu@gmail.com");
//		Associate accObj5=new Associate("A605","laya","bangalore","laya@gmail.com");
//		Associate accObj6=new Associate("A606","hari","coimbatore","hari@gmail.com");
//	
//		
//		associateList.add(accObj1);
//		associateList.add(accObj2);
//		associateList.add(accObj3);
//		associateList.add(accObj4);
//		associateList.add(accObj5);
//		associateList.add(accObj6);
		
	}	

	public Associate addAssociate(Associate cObj)  {
		return null;
			
	}

	public Associate viewByAssociateId(String associateId)  throws AssociateInvalidException{
		return null;
	}

	public Associate updateAssociate(String associateId, String associateAddress)throws AssociateInvalidException {
		return null;
	}

	@Override
	public List<Associate> viewAll() {
		return null;
	}

}
