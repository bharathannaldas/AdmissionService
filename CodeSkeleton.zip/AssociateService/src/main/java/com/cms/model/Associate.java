 package com.cms.model;
 import java.io.Serializable;

 

 
 public class Associate implements Serializable{	 	  	    	    	     	      	 	
 	
	
	private String associateId;	
	
	private String associateName;	
	
	private String associateAddress;	
	private String associateEmailId;

 }
