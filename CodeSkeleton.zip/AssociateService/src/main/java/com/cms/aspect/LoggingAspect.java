package com.cms.aspect;
import org.aspectj.lang.JoinPoint;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import org.aspectj.lang.annotation.After;


public class LoggingAspect {
	
	public void afterAdvice(JoinPoint joinPoint) {

		
		}
	
	
	  
	public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex)  
	{  
		
	
	
	}     
}
	 	  	    	    	     	      	 	
