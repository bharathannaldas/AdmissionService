package com.cms.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cms.exception.AdmissionInvalidException;
import com.cms.model.Admission;


@Service
public class AdmissionServiceImpl implements IAdmissionService {

	private ArrayList<Admission> admissionList=new ArrayList<Admission>();
	
	
	public ArrayList<Admission> getAdmissionList() {
		return admissionList;
	}

	public void setAdmissionList(ArrayList<Admission> admissionList) {
		this.admissionList = admissionList;
	}

	public AdmissionServiceImpl()
	{
//		Admission accObj1=new Admission(123L,"C501","A601",20000,"good");
//		Admission accObj2=new Admission(124L,"C502","A602",35000,"fair");
//		Admission accObj3=new Admission(125L,"C503","A603",23000,"vgood");
//		Admission accObj4=new Admission(126L,"C504","A604",40000,"vvgood");
//		Admission accObj5=new Admission(127L,"C505","A605",10000,"good");
//		Admission accObj6=new Admission(128L,"C506","A606",20000,"good");
//	
//		
//		admissionList.add(accObj1);
//		admissionList.add(accObj2);
//		admissionList.add(accObj3);
//		admissionList.add(accObj4);
//		admissionList.add(accObj5);
//		admissionList.add(accObj6);
		
	}	 
	
	public Admission registerAssociateForCourse(Admission admissionObj)  {

			
			return null;

	}

	public Admission getAdmissionFromList(long id) { 
		
		return null;
	}

	

	
	public Admission addFeedback(Long regNo, String feedback) throws AdmissionInvalidException {
		return null;
	}



	public List<String> viewFeedbackByCourseId(String courseId) throws AdmissionInvalidException{	 	  	    	    	     	      	 	
		return null;
	}

	public boolean deactivateAdmission(String courseId) {
		return false; 	      	 	
    }
    
    
    public List<Admission> viewAll() {
	    return null;
	}
}
