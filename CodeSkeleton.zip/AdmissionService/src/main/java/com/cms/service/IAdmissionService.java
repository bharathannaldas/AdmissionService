package com.cms.service;

import java.util.List;

import com.cms.exception.AdmissionInvalidException;
import com.cms.model.Admission;

public interface IAdmissionService {
	public Admission registerAssociateForCourse(Admission admission);
	public Admission addFeedback(Long regNo,String feedback) throws AdmissionInvalidException;
	public List<String> viewFeedbackByCourseId(String courseId) throws AdmissionInvalidException;
	public boolean deactivateAdmission(String courseId);
	public List<Admission> viewAll();

}
