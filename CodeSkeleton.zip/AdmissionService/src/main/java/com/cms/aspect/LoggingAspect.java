package com.cms.aspect;
import org.aspectj.lang.JoinPoint;


import org.springframework.stereotype.Component;




@Component
public class LoggingAspect {
	
	public void afterAdvice(JoinPoint joinPoint) {
		}
	
	
	  
	public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex)  
	{  	
	}     
}
	 	  	    	    	     	      	 	
