package com.cms.exception;

public class AdmissionInvalidException extends Exception {
	
	public AdmissionInvalidException(String message) {
		super(message);
	}
	
	public AdmissionInvalidException() {
	}

}
