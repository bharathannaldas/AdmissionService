package com.cms.proxy;


public interface ServiceProxy {

}